#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

void sig_user_print1(int signum);
void sig_user_print2(int signum);
int main(int argc, char *argv[]);

 
