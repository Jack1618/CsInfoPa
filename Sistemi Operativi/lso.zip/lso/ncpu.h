#include <stdio.h>
#include <stdlib.h>

#include <sys/types.h>
#include <regex.h>

#define CPU_PATTERN "^processor[[:space:]]*: [0-9]+$"
#define CPU_INFO_FILE "/proc/cpuinfo"

int main(int argc, char *argv[]);

 
