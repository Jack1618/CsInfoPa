#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

void sig_user_alarm(int signum);
void sig_user_print(int signum);
void sig_user_print_(int signum);
int main(int argc, char *argv[]);


