#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>

void put_into_tube(int file);
void look_into_tube(int file);

int main(int argc, char *argv[]);

 
