#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

char **make_args(char *argv[],int l, int r);
int main(int argc, char *argv[]);

 
